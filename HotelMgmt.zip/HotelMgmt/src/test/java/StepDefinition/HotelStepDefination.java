package StepDefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStepDefination {
	WebDriver driver;
@Given("^User is on hotel booking page$")
public void user_is_on_hotel_booking_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	System.setProperty("webdriver.chrome.driver", "C:/Users/sakraut/Desktop/libs/chromedriver.exe");
	 driver=new ChromeDriver();
	driver.get("C:\\Users\\sakraut\\Desktop\\registration.html");
	}


@When("^enters all valid details$")
public void enters_all_valid_details() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	WebElement firstNameTxt=driver.findElement(By.name("txtFN"));
	firstNameTxt.sendKeys("Aftab");
	WebElement lastNameTxt=driver.findElement(By.name("txtLN"));
	lastNameTxt.sendKeys("Shaikh");
	WebElement emailTxt=driver.findElement(By.name("Email"));
	emailTxt.sendKeys("aftabshaikh96@gmail.com");
	WebElement phoneTxt=driver.findElement(By.name("Phone"));
	phoneTxt.sendKeys("9768592991");
	Select dropdownCity = new Select(driver.findElement(By.name("city")));
	dropdownCity.selectByVisibleText("Pune");
	Select dropdownState = new Select(driver.findElement(By.name("state")));
	dropdownState.selectByVisibleText("Maharashtra");
	WebElement cardHolderNameTxt=driver.findElement(By.name("txtCardholderName"));
	cardHolderNameTxt.sendKeys("Aftab Shaikh");
	WebElement debitCardTxt=driver.findElement(By.name("debit"));
	debitCardTxt.sendKeys("1234567890");
	WebElement cvvTxt=driver.findElement(By.name("cvv"));
	cvvTxt.sendKeys("123");
	WebElement monthTxt=driver.findElement(By.name("month"));
	monthTxt.sendKeys("12");
	WebElement yearTxt=driver.findElement(By.name("year"));
	yearTxt.sendKeys("12");
	WebElement registerBtn=driver.findElement(By.xpath("//*[@id=\"btn\"]"));
	registerBtn.click();
}

@Then("^display succes page$")
public void display_succes_page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
	 String expUrl=driver.getCurrentUrl();
	   String actualurl="C:\\Users\\sakraut\\Desktop\\success.html";
	   assertEquals(expUrl, actualurl);
	   driver.close();
}

}




